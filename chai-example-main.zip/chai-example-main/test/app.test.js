const Cube = require('../src/app').Cube;
const Triangle = require('../src/app').Triangle;
const expect = require('chai').expect;

describe('Testing the Cube Functions', function() {
    it('1. The side length of the Cube', function(done) {
        let c1 = new Cube(2);
        expect(c1.getSideLength()).to.equal(2);
        done();
    });
    
    it('2. The surface area of the Cube', function(done) {
        let c2 = new Cube(5);
        expect(c2.getSurfaceArea()).to.equal(150);
        done();
    });
    
    it('3. The volume of the Cube', function(done) {
        let c3 = new Cube(7);
        expect(c3.getVolume()).to.equal(343);
        done();
    });
    
});

describe('Testing the triangle3D Functions', function() {
    it('1. The side length of the Triangle3D', function(done) {
        let c1 = new Triangle(2);
        expect(c1.getSideLength()).to.equal(2);
        done();
    });
    
    it('2. The Largeur of the Triangle3D', function(done) {
        let c55 = new Triangle(3);
        expect(c55.getLargeurLength()).to.equal(3);
        done();
    });

    it('3. The surface area of the Triangle3D', function(done) {
        let c2 = new Triangle(5);
        expect(c2.getSurfaceAreaTriangle()).to.equal(9);
        done();
    });
    
    it('4. The volume of the Triangle3D', function(done) {
        let c3 = new Triangle(7);
        expect(c3.getVolumeTriangle()).to.equal(27);
        done();
    });
    
});