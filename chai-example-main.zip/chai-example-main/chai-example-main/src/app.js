class Cube {
    constructor(length) {
        this.length = length;
    }
    
    getSideLength () {
        return this.length;
    }
    
    getSurfaceArea () {
        return (this.length * this.length) * 6;
    }
    
    getVolume () {
        return Math.pow(this.length,3);
    }
}

class Triangle {
    constructor(length) {
        this.length = length;
    }
    
    getBaseLength () {
        return this.length;
    }
    getHauteurLength () {
        return this.length;
    }
    getSurfaceArea () {
        return (this.length * this.length) / 2;
    }
    getVolume () {
        return Math.pow(this.length,3) /2;
    }
}

module.exports = {
    Cube:Cube,
    Triangle:Triangle
}