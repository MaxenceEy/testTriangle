class Cube {
    constructor(length) {
        this.length = length;
        this.largeur = 3;
this.hauteur = 3;
this.base = 6;
    }
    
    getSideLength () {
        return this.length;
    }
    
    getSurfaceArea () {
        return (this.length * this.length) * 6;
    }
    
    getVolume () {
        return Math.pow(this.length,3);
    }
}

class Triangle extends Cube {



    getLargeurLength () {
        return this.largeur;
    }

    getSurfaceAreaTriangle () {
        return (this.hauteur*this.base)/2;
    }

    getVolumeTriangle () {
        return (this.hauteur*this.largeur*this.base)/2;
    }



}

module.exports = {
    Cube:Cube,
    Triangle:Triangle
}